#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<sys/wait.h>

int main()
{
    pid_t gpid, ppid;

    // variable pid will store the value returned from fork() system call
    gpid = fork();

    // If fork() returns zero then it means it is child process.
    if (gpid > 0)
    {
        wait(NULL);
        // getpid() gives PID and getppid() gives ParentPID
        printf("I am the Grandparent process G and my pid is %d.\n",
               getpid());
    }

    else
    {
				pid_t grandparentPid = getppid();
        ppid = fork();
        // If value returned from fork() in not zero and >0 that means this is parent process
        if (ppid > 0)
        {
            // Printed Last
            wait(NULL);
            printf("I am the Parent process P and my pid is %d. My parent G has pid %d\n", getpid(), getppid());
        }
				else{
            printf("I am the Child process C and my pid is %d. My parent P has pid %d. My Grandparent G has pid %d\n", getpid(), getppid(), grandparentPid);
				}
			
    }

return 0;
}